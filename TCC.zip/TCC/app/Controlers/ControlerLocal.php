<?php

    require_once __DIR__."/../Models/LocalCrud.php";
    $crud = new LocalCrud();

    $listaLocais = $crud->getLocais();
?>
