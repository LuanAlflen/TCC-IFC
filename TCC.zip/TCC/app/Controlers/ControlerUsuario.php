<?php
    require '../../app/Models/Usuario.php';
    require '../../app/Models/UsuarioCrud.php';

    if ($_POST['acao'] == 'cadastrarUsuario') {
        //DADOS CHEGANDO DO FORMULARIO
        $nome = $_POST['nome'];
        $senha = $_POST['senha'];
        $email = $_POST['email'];
        $telefone = $_POST['telefone'];
        $cpf = $_POST['cpf'];
        $endereco = $_POST['endereco'];

        $user = new Usuario($nome, $senha, $email, $telefone, $cpf, $endereco);

        $teste = new UsuarioCrud();
        $resultado = $teste->insertUsuario($user);
        header("Location: ../Views/Cadastros/login.html");
    }elseif ($_POST['acao'] == 'getUsuario') {
//TESTE DO getUsuarios(PEGA DO BANCO TODOS OS USUARIOS)nao esta pegado o id
        $test = new UsuarioCrud();
        $resultado = $test->getUsuario(2);
    }elseif ($_POST['acao'] == 'getUsuario') {
//TESTE DO getUsuario(PEGA DO BANCO DE ACORDO COM ID)
        $test = new UsuarioCrud();
        $resultado = $test->getUsuarios();
    }elseif ($_POST['acao'] == 'updateUsuario'){
        echo "Nada por enquanto";
    }elseif ($_POST['acao'] == 'deleteUsuario'){
        $test = new UsuarioCrud();
        $resultado = $test->deleteUsuario(2);
    }else{
        echo "oi";
    }