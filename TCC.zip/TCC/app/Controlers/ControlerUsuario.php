<?php
    require '../../app/Models/Usuario.php';
    require '../../app/Models/UsuarioCrud.php';

    if (isset($_GET['acao'])){
        $action = $_GET['acao'];
    }else{
        $action = 'index';
    }
    if ($action == 'index'){
        $crud = new CategoriaCrud();
        $categorias = $crud->getCategorias();
        include "../Views/Template/Cabecalho.php";
        include "../Views/PaginaPrincipal/index.php";
        include "../Views/Template/Rodape.php";
    }

switch ($_GET['acao']){

        case 'cadastrar':

                    $user = new Usuario($_POST['nome'],$_POST['login'], $_POST['senha'], $_POST['email'], $_POST['telefone'], $_POST['cpf'], $_POST['endereco'],$_POST['tipuser']);
                    $test = new UsuarioCrud();
                    $resultado = $test->insertUsuario($user);

            break;
        case 'login':

            if ($_GET['acao'] = 'login' and isset($_POST['login']) and isset($_POST['senha'])){
                $user = new Usuario(null,$_POST['login'],$_POST['senha']);
                $crud = new UsuarioCrud();
                $resultado =  $crud->LoginUsuario($user);

                if ($resultado == 0){
                    header("Location:../Views/Formularios/login.php?erro=1");
                }else{
                    session_start();
                    $_SESSION['login'] = $user->getLogin();
                    include "../Views/Template/Cabecalho.php";
                    include "../Views/PaginaPrincipal/index.php";
                    include "../Views/Template/Rodape.php";
            }

            }elseif(!isset($_POST['login']) and isset($_POST['senha'])){
                header("Location: ../Views/Formularios/login.php?erro=1");
            }

            break;

//        case 'getUsuario':
//
//            //Passando id como padrao
//            $test = new UsuarioCrud();
//            $resultado = $test->getUsuario(2);
//
//            break;
//
//        case 'getUsuarios':
//
//            $test = new UsuarioCrud();
//            $resultado = $test->getUsuarios();
//            print_r($resultado);
//
//        break;
    }

    //TESTE UpdateUsuario BASEADO NO TRABALHO LOJA ANO PASSADO, AINDA NAO FUNCIONANDO
//    $crud = new UsuarioCrud();
//    $produto = new Usuario($_ POST["nome"], $_POST["senha"], $_POST["email"], $_POST["telefone"], $_POST['cpf'], $_POST['endereco']);
//    $crud->updateUsuario($crud);
//    header("location: ../Views/PaginaPrincipal/index.php");
