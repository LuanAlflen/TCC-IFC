   <div class="container">

        <footer>
            <div class="row">
                <div class="col-lg-12" style="margin-left: 25%">
                    <br><p> Você esta logado como <?php echo $_SESSION['login']; ?><!--Instituto Federal Catarinense - Campus Araquari, 2info1 - Luan Alflen e Bryan Matheus Krüger--></p>
                </div>

            </div>
        </footer>
   </div>