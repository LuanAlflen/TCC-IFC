   <div class="container">

        <footer>
            <div class="row">
                <div class="col-lg-12" style="margin-left: 25%">
                    <?php
                    $id = $_SESSION['id'];
                    $nome = $_SESSION['nome'];
                    $login = $_SESSION['login'];
                    $senha = $_SESSION['senha'];
                    $endereco = $_SESSION['endereco'];
                    $telefone = $_SESSION['telefone'];
                    $email = $_SESSION['email'];
                    $cpf = $_SESSION['cpf'];
                    $tipuser = $_SESSION['tipuser'];
                    ?>
                    <br><p> Você esta logado com <?php echo "
                    id = $id, 
                    nome = $nome,
                    login = $login,
                    senha = $senha,
                    endereco = $endereco,
                    telefone = $telefone,                 
                    email = $email,
                    cpf = $cpf,
                    tipuser = $tipuser. 
                    "; ?><!--Instituto Federal Catarinense - Campus Araquari, 2info1 - Luan Alflen e Bryan Matheus Krüger--></p>
                </div>

            </div>
        </footer>
   </div>