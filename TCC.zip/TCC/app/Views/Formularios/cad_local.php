<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">">>
	<link rel="stylesheet" href="../../../assets/css/main.css">
	<title>Formulario</title>
</head>
<body>



	<div class="container">
		<div class="form__top">
			<h2>Cadastro  <span>Quadra</span></h2>
		</div>		
		<form class="form__reg" action="">
			<!--<input class="input" type="file" placeholder="" required>-->
			<input class="input" type="text" placeholder="Nome" required autofocus>
            <input class="input" type="email" placeholder="Email" required>
            <input class="input" type="email" placeholder="Endereço" required>
            <input class="input" type="text" placeholder="Telefone" required>

			<textarea rows="5" cols="40" maxlength="500" placeholder="Descrição..."></textarea>
			<div class="btn__form">
            	<input class="btn__submit" type="submit" value="Limpar">
            	<input class="btn__reset" type="reset" value="Proximo">  <!--onclick="window.location.href='horario_funcionamento.html';">-->
            </div>


		</form>
	</div>
	
</body>
</html>