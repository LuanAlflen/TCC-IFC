<?php

require_once "../Models/LocalCrud.php";

$crud = new LocalCrud();
//seguranca
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

$local = $id;
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TCC- Luan e Bryan</title>

    <!-- Bootstrap Core CSS -->
    <link href="../../../assets/css/bootstrap.css" rel="stylesheet">


    <!-- site de custumização do bootstrap -->
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">-->

    <!-- Custom CSS -->
    <link href="../../../assets/css/shop-homepage.css" rel="stylesheet">
    <link rel="stylesheet" href="../../../assets/css/style.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>

    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <link class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../PaginaPrincipal/index.php">ALPE</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="#">Favoritos</a>
                    </li>
                    <li>
                        <a href="#">Em destaque</a>
                    </li>
                        <li class="dropdown pull-right">
                            <a href="#" class="dropdown-toggle pull-right" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <!-- ícone do user --> <i class="fa fa-user-o" aria-hidden="true"></i>
                                <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#">Editar</a></li>
                                <li><a href="#">Configurações</a></li>
                                <li><a href="#">Something else here</a></li>
                                <li role="separator" class="divider"></li>
                                <li><a href="#">Sair</a></li>
                            </ul>
                            <form class="navbar-form pull-right">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Buscar">
                                </div>
                                <button type="submit" class="btn btn-default">Pesquisar</button>
                            </form>

                </ul>
            </div>

            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>


    <div class="container">
                <div class="col-md-12">
                 <div class="thumb">

                     <div id="exemplo" class="col-md-3">
                         <p class="lead">Quadra do Joaozinho</p>
                         <div class="img-embrulho">
                             <img src="../../../assets/img/320x320.jpeg" alt="">
                         </div>
                         <br>
                         <p>Contem 2 quiosque e bla eu não tenho mais nada pra encher linguiça aqui, mas tenho que continuar</p>
                            <br><button id="reservarQuadra" class="btn btn-success" onclick="window.location.href='../PgCalendario/index.html';">Reservar </button>
                         </div>
                     </div>
                 <div class="col-md-4">
                    <p class="lead">Informações</p>
                         <div class="list-group">
                             <a class="list-group-item"><b>Estado: </b>Mata Fino</a>
                             <a class="list-group-item"><b>Cidade: </b>Cupuaçu</a>
                             <a class="list-group-item"><b>Bairro: </b>Horizonte</a>
                             <a class="list-group-item"><b>Endereço: </b> Avenida do Maria 3476</a>
                             <a class="list-group-item"><b>CEP: </b>89.235.002</a>
                         </div>
                    <p class="lead">Contato</p>
                    <div class="list-group">
                        <a class="list-group-item"><b>Email: </b> joãozin@gmail.com</a>
                        <a class="list-group-item"><b>Telefone: </b>3465-2375</a>

                    </div>

                </div>

                    <div class="col-md-4">

                        <img href="https://www.saberespractico.com/wp-content/uploads/2013/04/rio-amazonas-mapa-300x400.jpg" src="../../../assets/img/mapa.jpg">

                    </div>
            </div>




        <p class="lead">Avaliações</p>


        <div class="ratings">
            <p>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star-empty"></span>
           (12 avaliações)</p>

        </div>

            <br>
            <i style="float: left" class="fa fa-user-circle" aria-hidden="true"></i>
            <p style="float: left"><b>João:</b></p>
            <br><p>Gostei muito da quadra!  <i class="fa fa-thumbs-o-up" aria-hidden="true"></i><i class="fa fa-exclamation-triangle" aria-hidden="true"></i></p>

            <i style="float: left" class="fa fa-user-circle" aria-hidden="true"></i>
            <p style="float: left"><b>Pedro:</b></p>
            <br><p>Quadra boa, mas a falta de estacionamento atrapalha!  <i class="fa fa-thumbs-o-up" aria-hidden="true"></i><i class="fa fa-exclamation-triangle" aria-hidden="true"></i></p>

            <form>
                <input type="text"  placeholder="Digite seu comentario">
                <button type="submit" class="btn-success">Comentar</button>
            </form>
            <br>


        <div class="col-md-3">

            <a href="../PgEventos"> <img id="imgeventos" src="../../../assets/img/eventos.png" style="margin-left: 35%;" href="">
            </a>
        </div>
    <footer>
            <div class="row">
                <div class="col-lg-12" style="margin-left: 25%">
                    <br><p>Instituto Federal Catarinense - Campus Araquari, 2info1 - Luan Alflen e Bryan Matheus Krüger</p>
                </div>
            </div>
        </footer>

    <!-- Icones -->
    <script src="https://use.fontawesome.com/6114c79283.js"></script>
    <!-- jQuery -->
    <script src="../../../assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../../../assets/js/bootstrap.min.js"></script>


</body>



</html>
