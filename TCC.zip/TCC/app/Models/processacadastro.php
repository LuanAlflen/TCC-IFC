<?php
session_start();

include_once("conexao.php");

$nome = $_POST['nome'];
$senha = $_POST['senha'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$cpf = $_POST['cpf'];
$endereco = $_POST['endereco'];

$sql = "INSERT INTO usuarios (nome, senha, email, telefone, cpf, endereco ) VALUE ('$nome', '$senha', '$email', '$telefone', '$cpf',  '$endereco')";
$salvar = mysqli_query($conexao,$sql);
mysqli_close($conexao);

header("Location: ../Views/Cadastros/login.html");


?>