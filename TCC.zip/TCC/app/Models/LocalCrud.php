<?php

require_once 'DBConnection.php';
require_once 'Local.php';

class LocalCrud
{
    private $conexao;

    public function __construct()
    {
        $this->conexao = DBConnection::getConexao();
    }

    public function getLocal($id)
    {
        //RETORNA UMA CATEGORIA, DADO UM ID

        //FAZER A CONSULTA
        $sql = 'select * from locais where id='.$id;
        $resultado = $this->conexao->query($sql);

        //FETCH - TRANSFORMA O RESULTADO EM UM ARRAY ASSOCIATIVO
        $local = $resultado->fetch(PDO::FETCH_ASSOC);

        //CRIAR OBJETO DO TIPO CATEGORIA - USANDO OS VALORES DA CONSULTA
        $objetoLocal = new Usuario($local['id'], $local['nome'], $local['email'], $local['endereco'], $local['telefone'], $local['descricao'], $local['categoria']);

        //RETORNAR UM OBJETO CATEGORIA COM OS VALORES
        return $local;

    }


    public function getLocais()
    {
        $sql = "SELECT * FROM locais";

        $resultado = $this->conexao->query($sql);

        $locais = $resultado->fetchAll(PDO::FETCH_ASSOC);

        foreach ($locais as $local) {
            $nome = $local['nome'];
            $email = $local['email'];
            $endereco = $local['endereco'];
            $telefone = $local['telefone'];
            $descricao = $local['descricao'];
            $categoria = $local['categoria'];

            $obj = new Local($nome, $email, $endereco, $telefone, $descricao, $categoria);
            $Listalocal[] = $obj;
        }
        return $Listalocal;
    }
}