<?php

require_once 'DBConnection.php';
require_once 'Usuario.php';
class UsuarioCrud
{
    //SEMPRE QUE A CLASSE FOR INSTANCIADA, JA FAZ A CONEXÃO E GUARDA
    private $conexao;

    public function __construct()
    {
        $this->conexao = DBConnection::getConexao();
    }
    public function getUsuario($id)
    {
        //RETORNA UMA CATEGORIA, DADO UM ID

        //FAZER A CONSULTA
        $sql = 'select * from usuarios where id_usuario='.$id;
        $resultado = $this->conexao->query($sql);

        //FETCH - TRANSFORMA O RESULTADO EM UM ARRAY ASSOCIATIVO
        $usuario = $resultado->fetch(PDO::FETCH_ASSOC);

        //CRIAR OBJETO DO TIPO CATEGORIA - USANDO OS VALORES DA CONSULTA
        $objetoUsuario = new Usuario($usuario['id_usuario'], $usuario['nome'], $usuario['senha'], $usuario['email'], $usuario['telefone'], $usuario['cpf'], $usuario['endereco']);

        //RETORNAR UM OBJETO CATEGORIA COM OS VALORES
        return $objetoUsuario;

    }


    public function getUsuarios()
    {
        $sql = "SELECT * FROM usuarios";

        $resultado = $this->conexao->query($sql);

        $usuarios = $resultado->fetchAll(PDO::FETCH_ASSOC);

        foreach ($usuarios as $usuario) {
            $nome = $usuario['nome'];
            $senha = $usuario['senha'];
            $email = $usuario['email'];
            $telefone = $usuario['telefone'];
            $cpf = $usuario['cpf'];
            $endereco = $usuario['endereco'];

            $obj = new Usuario($nome, $senha, $email, $telefone, $cpf, $endereco);
            $listaUsuario[] = $obj;
        }
        return $listaUsuario;
    }

    //RECEBE UM OBJETTO $cat E INSERE NA TABELA categoria DO BD
    public function insertUsuario(Usuario $user)
    {

        //EFETUA A CONEXAO
        $this->conexao = DBConnection::getConexao();
        //MONTA O TEXTO DA INSTRUÇÂO SQL
        $sql = "insert into usuarios (nome, senha,endereco,telefone,email,cpf) 
        values ('{$user->getNome()}','{$user->getSenha()}','{$user->getEndereco()}','{$user->getTelefone()}','{$user->getEmail()}','{$user->getCpf()}')";

        try {//TENTA EXECUTAR A INSTRUCAO

            $this->conexao->exec($sql);
        } catch (PDOException $e) {//EM CASO DE ERRO, CAPTURA A MENSAGEM
            return $e->getMessage();
        }
    }

    public function updateUsuario(){

    }
    public function deleteUsuario($id){
        $query = "DELETE FROM usuarios WHERE id_usuario = $id";

        $resultado = $this->conexao->query($query);

        if ($resultado == false) {
            echo 'Error: cannot delete id '.$id.' from table usuarios';
            return false;
        } else {
            return true;
        }
    }
}
