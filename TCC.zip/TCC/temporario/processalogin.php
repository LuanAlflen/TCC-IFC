<?php

include_once("conexao.php");

    $userBusca = mysqli_query($conexao,"SELECT * FROM usuarios WHERE nome='".$_POST["nome"]."' AND senha='".$_POST["senha"]."'") or die(mysqli_error());

    if(mysqli_num_rows($userBusca) == 1){
    session_start();
    $_SESSION['nome'] = $_POST['nome'];
    $_SESSION['senha'] = $_POST['senha'];
    header("Location: ../Views/PaginaPrincipal/index.phtml");
}else{
    echo '<a>Usuario e senha invalidos! </a>';
}

?>

